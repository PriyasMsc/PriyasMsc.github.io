 <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>POC-POT <?php echo date('Y');?></p>
                </div>
            </div>
        </footer>
    </div>
    <!-- /.container -->

 

    <!-- Script to Activate the Carousel -->
    <script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>

</body>

</html>
