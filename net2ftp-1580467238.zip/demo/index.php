<?php 
include('inc/header.php');
include('inc/nav-bar.php');
include('inc/content_port_1.php');
include('inc/footer.php');
?>

