<?php 
include('inc/header.php');
include('inc/nav-bar.php');
include('inc/content_404.php');
include('inc/footer.php');
?>

